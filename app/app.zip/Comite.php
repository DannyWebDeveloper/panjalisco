<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Comite extends Model
{
    //
    protected $fillable = ['nombre', 'puesto', 'foto', 'visible'];


}

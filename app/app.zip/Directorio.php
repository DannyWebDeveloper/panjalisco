<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Directorio extends Model
{
    //
    protected $fillable = ['nombre', 'telefono', 'ext', 'email', 'area', 'titular', 'visible'];


}


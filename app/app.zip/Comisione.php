<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Comisione extends Model
{
    //
    protected $fillable = ['nombre', 'puesto', 'id_comite', 'visible'];


}

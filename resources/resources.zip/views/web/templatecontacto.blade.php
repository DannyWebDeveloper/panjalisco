<p>
    Mensaje recibído de {{ $data['name'] }}
</p>
<p>
    {{ $data['msg'] }}
</p>

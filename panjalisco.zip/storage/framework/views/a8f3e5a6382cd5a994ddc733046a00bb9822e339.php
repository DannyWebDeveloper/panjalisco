<!-- create.blade.php -->



<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
                <div class="card card-default">
                    <div class="card-header">
                        Incisos
                        <a href="<?php echo e(route('incisoForm')); ?>" class="btn btn-sm btn-primary btn-right"> Crear</a>
                    </div>

                <div class="card-body">
                    <table class="table table-striped table-hover">
                        <thead>
                        <tr>
                        <th>Articulo</th>
                        <th>Parrafo</th>
                        <th>inciso</th>
                        <th>Titulo</th>
                        <th>Visible</th>
                        <th colspan="2">&nbsp;</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $incisos->sortBy(['Numero_Parrafo']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><?php echo e($inc->Numero); ?> </td>
                                <td><?php echo e($inc->Numero_Parrafo); ?></td>
                                <td><?php echo e($inc->Numero_Letra_Inciso); ?></td>
                               <td> <?php echo e($inc->Titulo); ?>

                               <br>
                                    <b>Archivo</b> <?php echo e($inc->Archivo); ?>

                                    <br>
                                    <b>Link</b> <?php echo e($inc->Link); ?>

                               </td>
                               <td width ="10px">
                               <?php if($inc->Visible == 1): ?>
                                SI
                                <?php else: ?>
                                NO
                                <?php endif; ?>
                                </td>
                                <td width ="10px">
                                <a href="<?php echo e(route('incisoEdit', $inc->id)); ?>" class="btn">
                                    Editar
                                </a>
                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>;

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/admin/transparencia/incisos/index.blade.php ENDPATH**/ ?>
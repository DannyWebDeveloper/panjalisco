<?php $__env->startSection('title', '404'); ?>
<?php $__env->startSection('message', 'Página no encontrada'); ?>

<?php echo $__env->make('errors::layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/errors/404.blade.php ENDPATH**/ ?>
<!-- create.blade.php -->



<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
                <div class="card card-default">
                    <div class="card-header">
                        Categorias de extrados
                    </div>

                <div class="card-body">
                    <?php if(session('edit')): ?>
                    <h4>Actualizar categoria</h4>
                      <?php echo Form::model(session('edit'), ['route' => ['admincategoriasextrado.update', session('edit')[0]->id], 'method' => 'PUT']); ?>

                        <div class="form-group">
                        <?php echo e(Form::label('nombre', 'Nombre de la categoria')); ?>

                        <?php echo e(Form::text('nombre', session('edit')[0]->nombre, ['class' => 'form-control', 'id' => 'nombre'])); ?>

                        </div>
                        <div class="form-group">
                            <?php echo e(Form::submit('Actualizar', ['class' => 'btn btn-sm btn-primary'])); ?>

                        </div>
                        <?php echo Form::close(); ?>

                    <?php else: ?>
                    <h4>Aggar nueva</h4>
                    <?php echo Form::open(['route' => 'admincategoriasextrado.store', 'files' => true]); ?>

                    <div class="form-group">
                    <?php echo e(Form::label('nombre', 'Nombre de la categoria')); ?>

                    <?php echo e(Form::text('nombre', null, ['class' => 'form-control', 'id' => 'nombre'])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::submit('Guardar', ['class' => 'btn btn-sm btn-primary'])); ?>

                        <a class="btn btn-warning btn-sm"  href="<?php echo e(url('adm/adminextrados')); ?>">Cancelar</a>
                    </div>
                    <?php echo Form::close(); ?>

                    <?php endif; ?>
                    </div>


                    <h4>Lista de categorias</h4>
                    <table class="table table-striped table-hover">
                        <thead>
                        <tr>
                        <th>Id</th>
                        <th>Nombre</th>
                        <th>Cantidad de extrados</th>
                        <th colspan="2">&nbsp;</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($val->id); ?></td>
                               <td> <?php echo e($val->nombre); ?></td>
                               <td>
                                <?php $__currentLoopData = $extrados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($cat->id_categoria == $val->id): ?>
                                        <?php echo e($cat->cantidad); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </td>

                                <td width ="10px">
                                <a href="<?php echo e(route('admincategoriasextrado.edit', $val->id)); ?>" class="btn">
                                    Editar
                                </a>
                                </td>
                                <td width ="10px">

                                    <?php echo Form::open(['route' => ['admincategoriasextrado.destroy', $val->id], 'method' => 'DELETE']); ?>

                                        <button class="btn btn-sm btn-danger">Eliminar</button>
                                    <?php echo Form::close(); ?>


                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>;

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/admin/extrados/categoria.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="container main">
  <div class="row">
    <div class="col-md-8">
        <h1><?php echo e($noticia->titulo); ?></h1>
        <a href="<?php echo e(route('categoria', $categoria[0]->slug)); ?>"><?php echo e($categoria[0]->nombre); ?></a>

                    <?php if($noticia->img): ?>
                        <img src="<?php echo e($noticia->img); ?>" class="img-responsive" width="100%" height="300">
                    <?php endif; ?>
                    <hr>

                    <?php echo $noticia->body; ?>


                    <hr>

    </div>

    <div class="col-md-4 more-notes">
        <h3>Más notas</h3>
        <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $not): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="<?php echo e(route('noticia', $not->slug)); ?>"><?php echo e($not->titulo); ?></a>
            </li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
 </div>
</div>




<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/web/noticias/noticia.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'PAN Jalisco')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/functions.js')); ?>"></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style-admin.css')); ?>" rel="stylesheet">


    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">


</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light fixed-top bg-white shadow-sm ">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'PAN Jalisco')); ?>

                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item">
                        </li>
                    </ul>

                    <!-- Right Side Of Navbar -->

                    <ul class="navbar-nav ml-auto">

                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Entrar')); ?></a>
                            </li>
                        <?php else: ?>
                        <!--
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('admincategorias.index')); ?>">Categorias</a></li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('adminnoticias.index')); ?>">Noticias</a></li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('adminpaginas.index')); ?>">Páginas</a></li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('adminmenus.index')); ?>">Menús</a></li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('adminsliders.index')); ?>">Sliders</a></li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="<?php echo e(route('admintransparencia')); ?>" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Transparencia</a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                <a class="dropdown-item" href="<?php echo e(route('articulos')); ?>">Articulos</a>
                                <a class="dropdown-item" href="<?php echo e(route('parrafos')); ?>">Parrafos</a>
                                <a class="dropdown-item" href="<?php echo e(route('incisos')); ?>">Incisos</a>
                                <a class="dropdown-item" href="<?php echo e(route('documentos')); ?>">Documentos</a>
                                </div>
                            </li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('adminboletines.index')); ?>">Boletines</a></li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('adminextrados.index')); ?>">Extrados</a></li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('adminhemeroteca.index')); ?>">Hemeroteca</a></li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('admindirectorio.index')); ?>">Directorio</a></li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('admincomite.index')); ?>">Comité</a></li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('admincomision.index')); ?>">Comisión</a></li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('adminsocials.index')); ?>">Redes sociales</a></li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('adminenlaces.index')); ?>">Enlaces</a></li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('adminmapas.index')); ?>">Mapas</a></li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('adminusers.index')); ?>">Usuarios</a></li>
                            -->

                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">

                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Salir')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
        <br><br>
                        <?php if(auth()->guard()->guest()): ?>
                        <?php else: ?>
                        <a id="menu-movil" onclick="myFunction()">Menu</a>
                        <ul class="sidebar" id="sidebar">
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('admincategorias.index')); ?>">Categorias</a></li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('adminnoticias.index')); ?>">Noticias</a></li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('adminpaginas.index')); ?>">Páginas</a></li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('adminmenus.index')); ?>">Menús</a></li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('adminsliders.index')); ?>">Sliders</a></li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="<?php echo e(route('admintransparencia')); ?>" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Transparencia</a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                <a class="dropdown-item" href="<?php echo e(route('articulos')); ?>">Articulos</a>
                                <a class="dropdown-item" href="<?php echo e(route('parrafos')); ?>">Parrafos</a>
                                <a class="dropdown-item" href="<?php echo e(route('incisos')); ?>">Incisos</a>

                                </div>
                            </li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('adminboletines.index')); ?>">Boletines</a></li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('adminextrados.index')); ?>">Extrados</a></li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('adminhemeroteca.index')); ?>">Hemeroteca</a></li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('admindirectorio.index')); ?>">Directorio</a></li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('admincomite.index')); ?>">Comité</a></li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('admincomision.index')); ?>">Comisión</a></li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('adminsocials.index')); ?>">Redes sociales</a></li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('adminenlaces.index')); ?>">Enlaces</a></li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('adminmapas.index')); ?>">Mapas</a></li>
                            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('adminusers.index')); ?>">Usuarios</a></li>
                            </ul>
                        <?php endif; ?>


        <main class="py-4 contenedor-general">
            <?php if(session('info')): ?>
                <div class="container">
                    <div class="row">
                        <div class="col-md-8 col-offset-2">
                            <div class="alert alert-success">
                                <?php echo e(session('info')); ?>

                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php if(count($errors)): ?>
            <div class="container">
                    <div class="row">
                        <div class="col-md-8 col-offset-2">
                            <div class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    <?php echo $__env->yieldContent('scripts'); ?>
</body>
<?php if(auth()->guard()->guest()): ?>
<?php else: ?>
<style>
/*menu sidebar new*/
.sidebar{
    list-style: none;
    position: fixed !important;
    height: 88vh;
    width:15%;
    overflow-y: scroll;
}
.sidebar li{
    color:#000;
}
.contenedor-general{
    width:85%;
    float:right;
}
</style>
<?php endif; ?>
</html>
<?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/layouts/app.blade.php ENDPATH**/ ?>
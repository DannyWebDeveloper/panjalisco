<table class="table table-bordered table-striped table-condense">
    <thead>
        <tr>
        <th>Documento</th>
        <th>Fecha</th>
        </tr>
    </thead>
        <tbody>
<?php $__currentLoopData = $documentos_inciso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>
        <td> <a [href]="<?php echo e($doc->Archivo); ?>"><?php echo e($doc->NombreDocumento); ?></a> </td>
        <td> <?php echo e($doc->FechaDocumento); ?> </td>

    </tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/transparencia/documentos.blade.php ENDPATH**/ ?>
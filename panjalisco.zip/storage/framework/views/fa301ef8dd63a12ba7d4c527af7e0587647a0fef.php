<?php echo e(Form::hidden('id_user', auth()->user()->id)); ?>

<div class="form-group">
<?php echo e(Form::label('Id_Parrafo', 'Parrafo')); ?>

<?php echo e(Form::select('Id_Parrafo', $parrafos, $inciso->Id_Parrafo, ['class' => 'form-control'])); ?>

</div>

<div class="form-group">
    <?php echo e(Form::label('Numero_Letra_Inciso', 'Número o Letra de inciso')); ?>

    <?php echo e(Form::text('Numero_Letra_Inciso', null, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
    <?php echo e(Form::label('Titulo', 'Título del inciso')); ?>

    <?php echo e(Form::text('Titulo', $inciso->Titulo, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">

    <?php echo e(Form::label('Texto', 'Texto')); ?>

    <?php echo e(Form::text('Texto', $inciso->Texto, ['class' => 'form-control'])); ?>

</div>

<div class="form-group">
       <?php echo e(Form::label('Visible', 'Visibilidad')); ?>

       <?php echo Form::select('Visible',['1' => 'Visible','0'=>'No visible'],$inciso->Visible,['class'=>'form-control','placeholder'=>'Seleccione una opcion']); ?>

</div>
<div class="form-group">
       <?php echo e(Form::label('Orden', 'Orden')); ?>

       <?php echo e(Form::text('Orden', $inciso->Orden, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">

    <?php echo e(Form::label('Fecha', 'Fecha de actualización')); ?>

    <?php echo e(Form::text('Fecha', $inciso->Fecha,  ['class' => 'form-control datepicker' ])); ?>

</div>

<div class="form-group">

    <?php echo e(Form::submit('Guardar', ['class' => 'btn btn-sm btn-primary'])); ?>

    <a class="btn btn-warning btn-sm"  href="<?php echo e(url('adm/admintransparencia/incisos')); ?>">Cancelar</a>
</div>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>

    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

    <script  src="<?php echo e(asset('vendor/stringToSlug/src/jquery.stringtoslug.js')); ?>"></script>
    <script  src="<?php echo e(asset('vendor/stringToSlug/src/speakingurl.min.js')); ?>"></script>

    <script src="<?php echo e(asset('vendor/ckeditor/ckeditor.js')); ?>" defer></script>


    <script>


        jQuery(function($){

           // $( ".datepicker" ).focus(function(){
                $( ".datepicker" ).datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'yy-mm-dd'
                });
            //});
            $('input').attr('autocomplete','off');
    });




        </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/admin/transparencia/incisos/partials/form.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="container main">
      <!-- Three columns of text below the carousel -->
      <h2>ÚLTIMAS NOTICIAS</h2>
    <div class="row">
            <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-12">
                <div class="card border-primary flex-md-row mb-4 shadow-sm h-md-250">
                    <div class="card-body d-flex flex-column align-items-start">
                    <img class="card-img-left flex-auto d-none d-lg-block" alt="<?php echo e($nota->titulo); ?>" src="<?php echo e($nota->img); ?>" style="width: 200px; height: 200px;">
                    <strong class="d-inline-block mb-2 text-primary"><?php echo e($nota->nombre); ?></strong>
                    <h6 class="mb-0">
                        <a class="text-dark" href="#"><?php echo e($nota->titulo); ?></a>
                    </h6>
                    <div class="mb-1 text-muted small"><?php echo e($nota->created_at->format("m/d/Y")); ?></div>
                        <p class="card-text mb-auto resumen-nota"><?php echo e($nota->extracto); ?></p>
                        <a class="btn btn-outline-primary btn-sm" role="button" href="<?php echo e(asset('/notas/'.$nota->slug)); ?>">Leer nota</a>
                    </div>
                    </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($noticias->render()); ?>

    </div>

</div>




<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/web/noticias/todas.blade.php ENDPATH**/ ?>
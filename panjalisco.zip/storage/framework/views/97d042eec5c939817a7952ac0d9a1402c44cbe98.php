<?php $__env->startSection('content'); ?>
    <div class="contaniner">
        <div class="row">
            <div class="col-md-8 col-offset-2">
                <div class="card card-default">
                    <div class="card-header">
                            Ver Noticia
                    </div>

                <div class="card-body">
                    <p><strong>Titulo</strong> <?php echo e($noticia->tiutlo); ?> </p>
                    <p><strong>Slug</strong> <?php echo e($noticia->slug); ?> </p>
                    <p><strong>Categoria</strong> <?php echo e($categoria[0]->nombre); ?><p>
                    <p><strong>Extracto</strong> <?php echo e($noticia->extracto); ?></p>
                    <img src="<?php echo e($noticia->img); ?>" width="200">
                    <br>
                    <?php echo $noticia->body; ?>

                 </div>
            </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/admin/noticias/show.blade.php ENDPATH**/ ?>
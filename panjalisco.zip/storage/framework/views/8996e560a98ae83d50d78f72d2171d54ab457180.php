<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-offset-2">
                <div class="card card-default">
                    <div class="card-header">
                            Ver Slider <strong><?php echo e($slider->nombre); ?></strong>

                            <a class="btn btn-danger text-justify-right" href="<?php echo e(route('adminsliders.index')); ?>">Regresar</a>
                    </div>

                <div class="card-body">
                    <img src="<?php echo e($slider->img); ?>" width="100%" />
                    <p><?php echo e($slider->descripcion); ?></p>
                    <a href="<?php echo e($slider->link); ?>

                    "><?php echo e($slider->link); ?></a>

                    <p><strong>Estado </strong><?php echo e($slider->estado); ?></p>
                 </div>
            </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/admin/sliders/show.blade.php ENDPATH**/ ?>
<!-- create.blade.php -->



<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
                <div class="card card-default">
                    <div class="card-header">
                        Extrados
                        <a href="<?php echo e(route('adminextrados.create')); ?>" class="btn btn-sm btn-primary btn-right">Nuevo Extrado</a>
                    </div>

                <div class="card-body">
                    <div class="text-justify-right" style="width:100%; text-align:right;">
                        <a href="<?php echo e(route ('admincategoriasextrado.index')); ?>" class="btn btn-sm btn-primary">Categorias de extrado</a>
                    </div>
                    <br>
                    <table class="table table-striped table-hover">
                        <thead>
                        <tr>
                        <th>Titulo</th>
                        <th>Documento</th>
                        <th>Categoria</th>
                        <th>Fecha</th>
                        <th>Visible</th>
                        <th colspan="3">&nbsp;</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $extrados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                               <td> <?php echo e($val->titulo); ?></td>
                               <td><a href="/<?php echo e($val->documento); ?>">documento<a></td>
                               <td>
                                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($cat->id == $val->id_categoria): ?>
                                            <?php echo e($cat->nombre); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </th>
                               <td><?php echo e($val->fecha); ?></td>
                               <td>
                               <?php if($val->visible == 1): ?>
                                SI
                                <?php else: ?>
                                NO
                                <?php endif; ?>
                               </td>
                                <td width ="10px">
                                <a href="<?php echo e(route('adminextrados.edit', $val->id)); ?>" class="btn">
                                    Editar
                                </a>
                                </td>
                                <td width ="10px">
                                    <?php echo Form::open(['route' => ['adminextrados.destroy', $val->id], 'method' => 'DELETE']); ?>

                                        <button class="btn btn-sm btn-danger">Eliminar</button>
                                    <?php echo Form::close(); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>;

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/admin/extrados/index.blade.php ENDPATH**/ ?>
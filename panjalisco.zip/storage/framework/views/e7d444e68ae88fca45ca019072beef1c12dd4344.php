<?php echo e(Form::hidden('id_user', auth()->user()->id)); ?>


<div class="form-group">
    <?php echo e(Form::label('name', 'Nombre del usuario')); ?>

    <?php echo e(Form::text('name', null, ['class' => 'form-control', 'required' => 'required'])); ?>

</div>
<div class="form-group">
    <?php echo e(Form::label('email', 'Email de usuario')); ?>

    <?php echo e(Form::email('email', null, ['class' => 'form-control', 'required' => 'required'])); ?>

    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
</div>
<div class="form-group">
    <?php echo e(Form::label('password', 'Contraseña')); ?>

    <?php echo e(Form::password('password',  ['class' => 'form-control'])); ?>

    <!-- <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" autocomplete="new-password">
    -->
    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
        <span class="invalid-feedback" role="alert">
              <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
</div>
<div class="form-group">
    <?php echo e(Form::label('password_confirmation', 'Confirmar contraseña')); ?>

    <input id="password-confirm" type="password" class="form-control" name="password_confirmation"  autocomplete="new-password">
</div>


<div class="form-group">
    <?php echo e(Form::label('estatus', 'Estado del usuario')); ?>

    <br>
    <label>
    <?php echo e(Form::radio('estatus', 1)); ?> Activo
    </label>
    <label>
    <?php echo e(Form::radio('estatus', 0)); ?> Desactivado
    </label>

</div>

<div class="form-group">
    <?php echo e(Form::submit('Guardar', ['class' => 'btn btn-sm btn-primary'])); ?>

    <a class="btn btn-warning btn-sm"  href="<?php echo e(url('adm/adminusers')); ?>">Cancelar</a>

</div>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>

    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>



    <script>
        jQuery(function($){
            $('input').attr('autocomplete','off');
        });
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/admin/users/partials/form.blade.php ENDPATH**/ ?>
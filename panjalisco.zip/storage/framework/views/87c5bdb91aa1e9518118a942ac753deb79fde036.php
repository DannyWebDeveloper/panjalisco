<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo asset('css/pagina.css'); ?>">

    <div class="container justity-center">
        <div class="row">
            <div class="col-md-12">
                <div class="card card-default">
                    <div class="card-header">
                            Editar Inciso
                    </div>

                <div class="card-body">
                    <?php echo Form::model($inciso, ['route' => ['incisoUpdate', $inciso->id], 'method' => 'PUT', 'files' => true]); ?>

                        <?php echo $__env->make('admin.transparencia.incisos.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo Form::close(); ?>


                    <hr>

                    <?php if(count($documentos)>0): ?>
                    <table class="table">
                    <thead>
                    <tr><th>Documento</th> <th>Fecha documento</th><th>Visible</th><th colspan="2"></th> </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $documentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td>
                            <?php if($doc->Archivo): ?>
                            <a href="<?php echo e(asset($doc->Archivo)); ?>"><?php echo e($doc->NombreDocumento); ?></a><br>
                            <?php else: ?>
                            <a href="<?php echo e($doc->Link); ?>"><?php echo e($doc->NombreDocumento); ?></a>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($doc->FechaDocumento); ?></td>
                        <td><?php if($doc->visible == 1): ?>
                                SI
                                <?php else: ?>
                                NO
                                <?php endif; ?>
                                </td>
                       <td>
                            <a class="btn btn-sm edit-doc" href="<?php echo e(url('adm/admintransparencia/documentos/edit/'.$doc->id)); ?>">Editar</a>
                        </td>
                        <td>
                            <a class="btn btn-danger" onclick="return confirm('¿Está seguro que desea eliminar el documento?')" href="<?php echo e(route('documentoDelete',['id' => $doc->id])); ?>">Eliminar</a>
                        </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>
                    <?php endif; ?>
                        <div id="new-documento">
                            <h3>Agregar documento</h3>
                            <?php echo Form::open(['route' => 'documentoAddInciso', 'files' => true]); ?>

                            <?php echo e(Form::hidden('id_user', auth()->user()->id)); ?>

                            <?php echo e(Form::hidden('Id_Inciso', $inciso->id )); ?>

                            <div class="form-group">

                                <?php echo e(Form::label('NombreDocumento', 'Nombre del documento')); ?>

                                <?php echo e(Form::text('NombreDocumento', null, ['class' => 'form-control'])); ?>

                            </div>
                            <div class="form-group">

                                <?php echo e(Form::label('Link', 'Link')); ?>

                                <?php echo e(Form::text('Link', null, ['class' => 'form-control'])); ?>

                            </div>
                            <div class="form-group">

                                <?php echo e(Form::label('Archivo', 'Archivo')); ?>

                                <?php echo e(Form::file('Archivo', ['class' => 'form-control' ])); ?>

                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('FechaDocumento', 'Fecha')); ?>

                                <?php echo e(Form::text('FechaDocumento', null,  ['class' => 'form-control datepicker' ])); ?>

                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('visible', 'Visibilidad')); ?>

                                <?php echo Form::select('visible',['1' => 'Visible','0'=>'No visible'], 0 ,['class'=>'form-control','placeholder'=>'Seleccione una opcion']); ?>

                            </div>

                            <div class="form-group">

                            <?php echo e(Form::submit('Agregar', ['class' => 'btn btn-sm btn-primary'])); ?>

                            </div>
                            <?php echo Form::close(); ?>

                        </div>


                </div>


            </div>
            </div>
        </div>
    </div>


<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
jQuery(function($){
    $( ".edit-doc" ).click(function(){

    });
$('input').attr('autocomplete','off');
});


</script>
<?php $__env->stopSection(); ?>;



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/admin/transparencia/incisos/edit.blade.php ENDPATH**/ ?>
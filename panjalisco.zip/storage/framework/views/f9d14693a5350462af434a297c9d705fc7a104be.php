<?php $__env->startSection('title', '403'); ?>
<?php $__env->startSection('message', 'Acceso no autorizado'); ?>

<?php echo $__env->make('errors::layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/errors/403.blade.php ENDPATH**/ ?>
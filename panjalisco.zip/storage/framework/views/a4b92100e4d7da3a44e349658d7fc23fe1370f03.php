<table class="table table-bordered table-striped table-condense">
    <thead>
        <tr>
        <th>leter</th>
        <th>Título</th>
        </tr>
    </thead>
        <tbody>
<?php $__currentLoopData = $incisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inciso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr class="item-inciso" data-url="<?php echo e(route('transparencia.documento.inciso', ['id_inciso' => $inciso->idtrans_Incisos])); ?>" onclick="$('#inc').append('<a>-> Inciso <?php echo e($inciso->Numero_Letra_Inciso); ?></a>')">
        <td> <?php echo e($inciso->Numero_Letra_Inciso); ?> </td>
        <td> <?php echo e($inciso->Titulo); ?> </td>

    </tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<script>
$('.item-inciso').on('click', function(){
            var token = $('meta[name="csrf-token"]').attr('content'),
            $this = $(this),
            url = $this.data('url');
            $.post(url,
        {
            _token: token,
            id: 1,
        },
        function(data, status){
            $("#list-documentos").empty().html(data);
            $("#list-incisos").hide();
        });
    });
</script>
<?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/web/transparencia/incisos.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Pan Jalisco</title>

    <!-- Bootstrap core CSS -->
    <!-- <link href="https://getbootstrap.com/docs/4.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    -->

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
    <!-- Custom styles for this template -->
    <link href="css/carousel.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(URL::asset('/css/home.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('/css/styles.css')); ?>">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

  </head>
  <body>
    <header>
  <nav class="navbar navbar-expand-md fixed-top">
    <a class="navbar-brand" href="<?php echo e(route('inicio')); ?>">
        <img src="<?php echo e(URL::asset('/img/logo_pan.png')); ?>" class="img-logo">
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <i class="fa fa-bars"></i>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
      <ul class="navbar-nav ml-auto">
      <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($menu->nivel == 'Padre'): ?>
        <li class="nav-item <?php echo e(($menu->cantidad_subs > 0) ? 'dropdown' : ''); ?>">
         <?php if($menu->link_externo == null && $menu->id_pagina != null): ?>
            <?php $__currentLoopData = $slugs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($slug->id == $menu->id): ?>
                <a class="nav-link <?php echo e(($menu->cantidad_subs  > 0) ? 'dropdown-toggle': ''); ?> " href="/<?php echo e($slug->slug); ?>" <?php if($menu->cantidad_subs  > 0): ?> id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true" <?php endif; ?>>
                            <?php echo e($menu->nombre); ?>

                </a>

                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($sub->nivel == 'Hijo' && $sub->id_padre == $menu->id): ?>
                          <?php if($sub->link_externo == null): ?>
                            <?php $__currentLoopData = $slugs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($slug->id == $sub->id): ?>
                                <a class="dropdown-item" href="<?php echo e($slug->slug); ?>"><?php echo e($sub->nombre); ?>1111</a>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php else: ?>
                            <a class="dropdown-item" href="<?php echo e($sub->link_externo); ?>" target="_blank"><?php echo e($sub->nombre); ?></a>
                          <?php endif; ?>
                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php elseif($menu->link_externo != null && $menu->id_pagina == null): ?>
            <a class="nav-link <?php echo e(($menu->cantidad_subs  > 0) ? 'dropdown-toggle': ''); ?> " href="<?php echo e($menu->link_externo); ?>" target="_blank" <?php if($menu->cantidad_subs  > 0): ?> id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true" <?php endif; ?>>
                <?php echo e($menu->nombre); ?>

            </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($sub->nivel == 'Hijo' && $sub->id_padre == $menu->id): ?>
                          <?php if($sub->link_externo == null): ?>
                            <?php $__currentLoopData = $slugs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($slug->id == $sub->id): ?>
                                <a class="dropdown-item" href="/<?php echo e($slug->slug); ?>"><?php echo e($sub->nombre); ?></a>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php else: ?>
                          <a class="dropdown-item" href="/<?php echo e($sub->link_externo); ?>" target="_blank"><?php echo e($sub->nombre); ?></a>
                          <?php endif; ?>
                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
        <?php else: ?>
            <a class="nav-link <?php echo e(($menu->cantidad_subs  > 0) ? 'dropdown-toggle': ''); ?> " href="#" target="_blank" <?php if($menu->cantidad_subs  > 0): ?> id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true" <?php endif; ?>>
                <?php echo e($menu->nombre); ?>

            </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($sub->nivel == 'Hijo' && $sub->id_padre == $menu->id): ?>
                          <?php if($sub->link_externo == null): ?>
                            <?php $__currentLoopData = $slugs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($slug->id == $sub->id): ?>
                                <a class="dropdown-item" href="/<?php echo e($slug->slug); ?>"><?php echo e($sub->nombre); ?></a>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php else: ?>
                          <a class="dropdown-item" href="/<?php echo e($sub->link_externo); ?>" target="_blank"><?php echo e($sub->nombre); ?></a>
                          <?php endif; ?>
                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
         <?php endif; ?>
        </li>
        <?php endif; ?>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!--

      <li class="nav-item <?php echo e(($submenus[0]->id_padre !=  $menu->id) ? 'dropdown' : ''); ?>" >
                    <?php if($menu->id_pagina): ?>
                          <?php $__currentLoopData = $slugs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($slug->id == $menu->id): ?>
                                    <?php $__currentLoopData = $submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <?php if($sub->id_padre == $menu->id): ?>
                                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink<?php echo e($i); ?>" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <?php echo e($menu->nombre); ?>

                                                </a>
                                                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink<?php echo e($i); ?>">
                                                    <?php if($sub->id_pagina): ?>
                                                        <?php $__currentLoopData = $slugs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($slug->id == $menu->id): ?>
                                                            <a class="dropdown-item" href="<?php echo e(asset($slug->slug)); ?>"><?php echo e($sub->nombre); ?></a>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </div>
                                            <?php elseif($sub->id_padre): ?>

                                                <a class="nav-link" href="<?php echo e(asset($slug->slug)); ?>"><?php echo e($menu->nombre); ?></a>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
        </li>

    -->



      <!--
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          ACTUALIDAD
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="#">Boletínes y comunicados</a>
          <a class="dropdown-item" href="#">En los medios</a>
          <a class="dropdown-item" href="#">Convocatorias</a>
          <a class="dropdown-item" href="#">Estrados Electrónicos</a>
          <a class="dropdown-item" href="#">Videos</a>
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          PARTICIPA
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="#">Afílate</a>
          <a class="dropdown-item" href="#">Opina</a>
          <a class="dropdown-item" href="#">Redes Sociales</a>
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          EN ACCIÓN
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="#">En acción</a>
          <a class="dropdown-item" href="#">Nuestros Gobiernos</a>
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          ESTRUCTURA
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="#">Consejo Estatal</a>
          <a class="dropdown-item" href="#">Comité Directivo Estatal</a>
          <a class="dropdown-item" href="#">Dirigencias</a>
          <a class="dropdown-item" href="#">Panistas jaliscienses en el CEN</a>
          <a class="dropdown-item" href="#">Comité Directivo Estatal</a>
          <a class="dropdown-item item-submenu" href="#">
          Comisiones
          </a>
          <div class="dropdown-menu submenu" href="#" aria-labelledby="navbarDropdownSubMenuLink">
            <a class="dropdown-item" href="#">Comisión Organizadora de elecciones</a>
            <a class="dropdown-item" href="#">Comisión Organizadora Electoral del PAN Jalisco</a>
          </div>
        </div>
      </li>

      <li class="nav-item active">
        <a class="nav-link" href="transparencia">TRANSPARENCIA</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">CONTÁCTANOS</a>
      </li>
      -->
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(asset('/transparencia')); ?>">TRANSPARENCIA</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('contacto')); ?>">CONTÁCTANOS</a>
      </li>
    </ul>

     </div>
  </nav>
</header>

<?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/layouts/header.blade.php ENDPATH**/ ?>
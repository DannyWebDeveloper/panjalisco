<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo asset('css/pagina.css'); ?>">

    <div class="container">
        <div class="row">
            <div class="col-md-10">
                <div class="card card-default">
                    <div class="card-header">
                            Editar Página
                    </div>

                <div class="card-body">
                    <?php echo Form::model($pagina, ['route' => ['adminpaginas.update', $pagina->id], 'method' => 'PUT', 'files' => true]); ?>

                        <?php echo e(Form::hidden('id', $pagina->id)); ?>

                        <?php echo $__env->make('admin.paginas.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo Form::close(); ?>



                    <?php if($archivos): ?>
                    <hr>
                    <h5>Archivos en la página</h5>
                    <table class="table">
                        <thead><tr><th>Documento</th><th colspan="3">Fecha</th></tr></thead>
                        <tbody>
                        <?php $__currentLoopData = $archivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="ver">
                                <td><a href="<?php echo e($file->file); ?>"> <?php echo e($file->nombre); ?> </a></td> <td> <?php echo e($file->fecha); ?> </td>
                                <td>Editar</td>
                                <td><a href="<?php echo e(route('delete-archivo-pagina', $file->id)); ?>" class="btn btn-danger"> Eliminar </a> </td>
                        </tr>
                        <tr class="filei" id="file<?php echo e($file->id); ?>" style="display:none;">
                            <td colspan="3">
                            <?php echo Form::open(['route' => ['update-archivo-pagina', $file->id]]); ?>

                                <?php echo e(Form::label('nombre', 'Nombre de archivo')); ?>

                                <?php echo e(Form::text('nombre', $file->nombre, ['class' => 'form-control', 'id' => 'nombre'.$file->id])); ?>


                                <?php echo e(Form::label('fecha', 'Fecha de archivo')); ?>

                                <?php echo e(Form::text('fecha', $file->fecha, ['class' => 'form-control datepicker', 'id' => 'fecha'.$file->id, 'autocomplete' => false])); ?>


                                <?php echo e(Form::submit('Guardar', ['class' => 'btn btn-primary'])); ?>

                            <?php echo Form::close(); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>

                </div>
            </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>;



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/admin/paginas/edit.blade.php ENDPATH**/ ?>
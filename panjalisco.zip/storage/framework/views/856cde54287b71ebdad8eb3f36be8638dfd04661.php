<?php $__env->startSection('content'); ?>
    <div class="contaniner">
        <div class="row">
            <div class="col-md-8 col-offset-2">
                <div class="card card-default">
                    <div class="card-header">
                            Ver Categoria
                    </div>

                <div class="card-body">
                    <p><strong>Nombre</strong> <?php echo e($categoria->nombre); ?> </p>
                    <p><strong>Slug</strong> <?php echo e($categoria->slug); ?> </p>
                 </div>
            </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>;

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/admin/categorias/show.blade.php ENDPATH**/ ?>
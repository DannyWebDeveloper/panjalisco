<table class="table table-bordered table-striped table-condense">
        <tbody>
        <?php if($whois == 'inciso'): ?>
        <?php $__currentLoopData = $documentos_inciso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $incisos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th colspan="3" style="background-color: #F7F7F7"><?php echo e($date); ?> (<?php echo e($incisos->count()); ?>)</th>
                </tr>
            <?php $__currentLoopData = $incisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td> <?php echo e(date('d', strtotime($doc->FechaDocumento)). ' de '. $Meses[date('m', strtotime($doc->FechaDocumento))]); ?> </td>
                <!-- <td> <?php echo e(date('M', strtotime($doc->FechaDocumento))); ?> </td>-->
                <td>
                    <?php if($doc->Archivo): ?>
                    <a href="transparencia/<?php echo e($doc->Archivo); ?>"><?php echo e($doc->NombreDocumento); ?></a>
                    <?php else: ?>
                    <a href="<?php echo e($doc->Link); ?>"><?php echo e($doc->NombreDocumento); ?></a>
                    <?php endif; ?>
                </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <?php if($whois == 'parrafo'): ?>
        <?php $__currentLoopData = $documentos_parrafo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $parrafos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th colspan="3" style="background-color: #F7F7F7"><?php echo e($date); ?> (<?php echo e($parrafos->count()); ?>)</th>
                </tr>
            <?php $__currentLoopData = $parrafos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td> <?php echo e(date('d', strtotime($doc->FechaDocumento)). ' de '. $Meses[date('m', strtotime($doc->FechaDocumento))]); ?> </td>
                <!-- <td> <?php echo e(date('M', strtotime($doc->FechaDocumento))); ?> </td>-->
                <td>
                <?php if($doc->Link != 'NULL'): ?>
                <a href="<?php echo e($doc->Link); ?>"><?php echo e($doc->link); ?>Link</a>
                <?php else: ?>
                <a href="transparencia/<?php echo e($doc->Archivo); ?>"><?php echo e($doc->NombreDocumento); ?></a>
                <?php endif; ?>
                </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

</tbody>
</table>
<?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/web/transparencia/documentos.blade.php ENDPATH**/ ?>
  <div class="container main">
    <h1>Contácto</h1>
<?php if(session('info')): ?>
<div class="row">
    <div class="col-md-8 col-offset-2">
        <div class="alert alert-success">
            <?php echo e(session('info')); ?>

        </div>
    </div>
</div>
<?php endif; ?>
<?php if(count($errors)): ?>
    <div class="row">
                        <div class="col-md-8 col-offset-2">
                            <div class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                    </div>
<?php endif; ?>

<div class="row">
    <div class="col-md-8 col-offset-2">
    <?php echo Form::open(['route' => 'send-contacto', 'files' => true]); ?>

    <div class="form-group">
        <?php echo e(Form::label('name', 'Nombre')); ?>

        <?php echo e(Form::text('name', null, ['class' => 'form-control'])); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('email', 'Correo electrónico')); ?>

        <?php echo e(Form::text('email', null, ['class' => 'form-control'])); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('telefono', 'Teléfono')); ?>

        <?php echo e(Form::text('telefono', null, ['class' => 'form-control'])); ?>

    </div>

    <div class="form-group">
    <?php echo e(Form::label('msg', 'Mensaje')); ?>

    <?php echo e(Form::textarea('msg', null, ['class' => 'form-control'])); ?>

    </div>
    <div class="form-group">

    <?php echo e(Form::submit('Enviar', ['class' => 'btn btn-md btn-primary'])); ?>

    </div>


    <?php echo Form::close(); ?>


</div>
</div>
</div>




<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/web/contacto.blade.php ENDPATH**/ ?>
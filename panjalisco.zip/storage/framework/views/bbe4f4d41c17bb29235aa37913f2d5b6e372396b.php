<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col-md-8">
        <h1><?php echo e($noticia->titulo); ?></h1>
        <a href="<?php echo e(route('categoria', $categoria[0]->slug)); ?>"><?php echo e($categoria[0]->nombre); ?></a>
            <div class="card card-default">

                <div class="card-body">
                    <?php if($noticia->img): ?>
                        <img src="<?php echo e($noticia->img); ?>" class="img-responsive" width="100%" height="300">
                    <?php endif; ?>
                    <hr>

                    <?php echo $noticia->body; ?>


                    <hr>
                </div>

            </div>

    </div>

    <div class="col-md-4">
    <h3>Más notas</h3>
    </div>
 </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/noticias/noticia.blade.php ENDPATH**/ ?>
<main role="main">

  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img class="bd-placeholder-img" width="100%" height="100%" focusable="false" role="img" src="img/seaj.jpg">
          <div class="carousel-caption text-left">
            <h1>SEAJ</h1>
            <p>En Puerto Vallarta se concluyeron los últimos dos Talleres Nacionales de Formadores que capacitaron a 100 jóvenes de todo el país. ¡Felicidades a los participantes por su compromiso y dedicación!</p>
          </div>
      </div>
      <div class="carousel-item">
        <img class="bd-placeholder-img" width="100%" height="100%" focusable="false" role="img" src="img/capacitacion.jpg">
          <div class="carousel-caption text-left">
            <p>Participa Mtra. Angélica Pérez Plazola, Secretaria Estatal de Formación y Capacitación en taller de Dirigentes Municipales del PAN</p>
        </div>
      </div>
      <div class="carousel-item">
        <img class="bd-placeholder-img" width="100%" height="100%" focusable="false" role="img" src="img/tomaprotesta.jpg">
          <div class="carousel-caption text-left">
            <p>Toma de Protesta de Comité Directivo Municipal del PAN en Guadalajara</p>
        </div>
      </div>
    </div>
    <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>


  <div class="container">

    <!-- Three columns of text below the carousel -->
    <div class="row">
    <h2>ÚLTIMAS NOTICIAS</h2>
    <div class="col-sm-12">

    </div>


    </div><!-- /.row -->




  </div><!-- /.container -->


  

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/inicio.blade.php ENDPATH**/ ?>
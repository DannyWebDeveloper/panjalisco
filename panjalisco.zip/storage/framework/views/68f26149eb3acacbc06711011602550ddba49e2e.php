<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-offset-2">
                <div class="card card-default">
                    <div class="card-header">
                            Ver Página
                    </div>

                <div class="card-body">
                    <p><strong>Titulo</strong> <?php echo e($pagina->tiutlo); ?> </p>
                    <p><strong>Slug</strong> <?php echo e($pagina->slug); ?> </p>

                    <img src="<?php echo e($pagina->img); ?>" width="200">
                    <br>
                    <?php echo $pagina->body; ?>

                    <br>
                    <?php if($archivos): ?>
                    <hr>
                    <h5>Archivos en la página</h5>
                    <table class="table">
                        <thead><tr><th>Documento</th><th>Fecha</th></tr></thead>
                        <tbody>
                        <?php $__currentLoopData = $archivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="ver">
                                <td><a href="<?php echo e($file->file); ?>"> <?php echo e($file->nombre); ?> </a></td> <td> <?php echo e($file->fecha); ?> </td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                 </div>
            </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/admin/paginas/show.blade.php ENDPATH**/ ?>
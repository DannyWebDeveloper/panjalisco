<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-offset-2">
                <div class="card card-default">
                    <div class="card-header">
                            Ver Menú
                    </div>

                <div class="card-body">
                    <p><strong>Nombre</strong> <?php echo e($menu->nombre); ?> </p>

                    <?php if($menu->id_pagina > 0): ?>
                    <p><strong>Enlace</strong> <?php echo e($slug_menu[0]->slug); ?> </p>
                    <?php else: ?>
                    <p><strong>Enlace</strong> <?php echo e($menu->link_externo); ?> </p>
                    <?php endif; ?>
                    <br>

                    <?php if(count($submenus) > 0): ?>
                    <h3>Submenus derivados</h3>
                    <?php endif; ?>
                    <?php echo Form::open(['route' => 'reorder-menu']); ?>

                    <table class="table">
                        <thead>
                            <tr><th>Nombre</th><th>URL</th><th style="width:50px;">Orden</th> </tr>
                        </thead>
                        <tbody>

                    <?php $__currentLoopData = $submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                            <?php echo e($sub->nombre); ?>

                            </td>
                            <td>
                        <?php if($sub->id_pagina > 0): ?>

                            <?php $__currentLoopData = $slug_submenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slu_sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($slu_sub->slug); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                          <?php echo e($sub->link_externo); ?>

                        <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e(Form::text($sub->id, $sub->orden, ['class' => 'form-control input-sm', 'id' => 'orden' ])); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                 <td colspan="2"></td>
                                 <td>
                                 <?php echo e(Form::hidden('rows', count($submenus))); ?>

                                 <?php echo e(Form::submit('Reordenar ', ['class' => 'btn btn-primary'])); ?>

                                 </td>
                            </tr>

                        </tbody>
                    </table>

                    <?php echo Form::close(); ?>

                    <br>

                 </div>
            </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/admin/menus/show.blade.php ENDPATH**/ ?>
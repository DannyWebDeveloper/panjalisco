<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="col-md-8 col-md-offset-2">
        <h1>Noticias</h1>


        <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <br>
            <div class="card card-default">
                <div class="card-header">
                <?php echo e($nota->titulo); ?>

                </div>
                <div class="card-body">
                    <?php if($nota->img): ?>
                        <img src="<?php echo e($nota->img); ?>" class="img-responsive" width="100%" height="100">
                    <?php endif; ?>
                </div>
                <a href="<?php echo e(route('noticia', $nota->slug)); ?>">Leer mas</a>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($noticias->render()); ?>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/noticias/todas.blade.php ENDPATH**/ ?>
<?php echo e(Form::hidden('id_user', auth()->user()->id)); ?>


<div class="form-group">

    <?php echo e(Form::label('titulo', 'Titulo de la pagina')); ?>

    <?php echo e(Form::text('titulo', null, ['class' => 'form-control', 'id' => 'titulo'])); ?>

</div>

<div class="form-group">

    <?php echo e(Form::label('slug', 'URL Amigable')); ?>

    <?php echo e(Form::text('slug', null, ['class' => 'form-control', 'id' => 'slug'])); ?>

</div>

<div class="form-group">

    <?php echo e(Form::label('img', 'Imagen')); ?>

    <?php echo e(Form::file('img', ['class' => 'form-control' ])); ?>

</div>

<div class="form-group">
    <?php echo e(Form::label('estado', 'Estado de la pagina')); ?>

    <br>
    <label>
    <?php echo e(Form::radio('estado', 'PUBLICADO')); ?> Publicada
    </label>
    <label>
    <?php echo e(Form::radio('estado', 'BORRADOR')); ?> Borrador
    </label>

</div>
<div class="form-group">

    <?php echo e(Form::label('body', 'Cuerpo de la pagina')); ?>

    <?php echo e(Form::textarea('body', null, ['id' => 'body'])); ?>

</div>
<div class="form-group">
    <?php echo e(Form::label('has_file', 'Esta página mostrará archivos')); ?>

    <?php echo e(Form::checkbox("has_file","SI",false, ["class" => "form-group"])); ?>

</div>

<div class="form-group">
Archivos (can attach more than one): <br>
<input multiple="multiple" name="archivos[]" type="file">
</div>


<div class="form-group">

    <?php echo e(Form::submit('Guardar', ['class' => 'btn btn-sm btn-primary'])); ?>

    <a class="btn btn-warning btn-sm"  href="<?php echo e(url('adm/adminpaginas')); ?>">Cancelar</a>
</div>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>

    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

    <script  src="<?php echo e(asset('vendor/stringToSlug/src/jquery.stringtoslug.js')); ?>"></script>
    <script  src="<?php echo e(asset('vendor/stringToSlug/src/speakingurl.min.js')); ?>"></script>

    <script src="<?php echo e(asset('vendor/ckeditor/ckeditor.js')); ?>" defer></script>


    <script>


        jQuery(function($){

            $("#titulo, #slug").stringToSlug({
                callback: function(text){
                    $("#slug").val(text);
                }
            });

            CKEDITOR.replace( 'body', {
                filebrowserUploadUrl: "<?php echo e(route('upload', ['_token' => csrf_token() ])); ?>",
                filebrowserUploadMethod: 'form'
            });

            //click, para ver opciones de un archivo, en editar pagina
            $(".ver").click(function () {
                $( this ).next( ".filei" ).css( "display", "block" );
            });

           // $( ".datepicker" ).focus(function(){
                $( ".datepicker" ).datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'yy-mm-dd'
                });
            //});
            $('input').attr('autocomplete','off');
    });




        </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/admin/paginas/partials/form.blade.php ENDPATH**/ ?>
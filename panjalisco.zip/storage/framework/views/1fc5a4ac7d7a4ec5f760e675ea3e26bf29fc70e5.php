<p>
    Mensaje recibído de <?php echo e($data['name']); ?>

</p>
<p>
    <?php echo e($data['msg']); ?>

</p>
<?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/web/templatecontacto.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
                <div class="card card-default">
                    <div class="card-header">
                        Administración transparencia
                    </div>

                    <div class="card-body">
                    <a class="btn" href="<?php echo e(route('articuloForm')); ?>">Nuevo articulo</a>
                     <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>No. art</th>
                                <th>Titulo</th>
                                <th>Visible</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $art): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <?php echo e($art->Numero); ?></td>
                                <td><?php echo e($art->Titulo); ?></td>
                                <td><?php if($art->Visible == 1): ?>
                                    SI
                                    <?php else: ?> NO
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a class="btn btn-primary" href="<?php echo e(route('showParrafosAdmin', $art->id)); ?>">Parrafos</a>
                                    <a class="btn btn-primary" href="<?php echo e(route('articuloEdit', $art->id)); ?>">Editar</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                     </table>

                    <hr>
                    <?php if(session('parrafos')): ?>
                    <h4>parrafos</h4>
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                            <th>No. Parrafo</th>
                            <th>Titulo</th>
                            <th>Visible</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = session('parrafos'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($p->Numero_Parrafo); ?></td>
                        <td><?php echo e($p->Titulo); ?></td>
                        <td><?php if($art->Visible == 1): ?>
                                    SI
                                    <?php else: ?> NO
                                    <?php endif; ?></td>
                        <td>
                         <a class="btn btn-primary" href="<?php echo e(route('showIncisosAdmin', $p->idtras_Parrafos)); ?>">Detalles</a>
                        </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <?php endif; ?>

                    <?php if(session('incisos')): ?>
                    <h4>Incisos</h4>
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                            <th>No. inciso  </th>
                            <th>Titulo</th>
                            <th>Visible</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = session('incisos'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($inc->Numero_Parrafo); ?></td>
                        <td><?php echo e($inc->Titulo); ?></td>
                        <td><?php if($inc->Visible == 1): ?>
                                    SI
                                    <?php else: ?> NO
                                    <?php endif; ?></td>
                        <td>
                        <a class="btn btn-primary" href="<?php echo e(route('showDocumentosAdmin', $inc->idtrans_Incisos)); ?>">Detalles</a>
                         </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <?php endif; ?>

                    <?php if(session('documentos')): ?>
                    <h4>Documentos</h4>
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                            <th>Documento  </th>
                            <th>Fecha </th>
                            <th>Visible</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = session('documentos'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($doc->NombreDocumento); ?></td>
                        <td><?php echo e($doc->FechaDocumento); ?></td>
                        <td><?php if($doc->visible == 1): ?> SI <?php else: ?> NO <?php endif; ?></td>
                        <td>
                         </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <?php endif; ?>
                    </div>
                </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>;

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/admin/transparencia/index.blade.php ENDPATH**/ ?>
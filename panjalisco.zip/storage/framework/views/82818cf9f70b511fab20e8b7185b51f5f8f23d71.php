  <div class="container main">
    <h1>Aviso de privacidad</h1>
    <embed src="<?php echo e(asset('vendor/pdfjs/web/viewer.html?file=aviso-privacidad.pdf')); ?> " width="100%" style="border:none; height:120vh;" />

</div>




<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/web/avisodeprivacidad.blade.php ENDPATH**/ ?>
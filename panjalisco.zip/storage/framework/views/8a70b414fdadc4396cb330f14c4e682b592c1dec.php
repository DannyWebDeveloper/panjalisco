<?php echo e(Form::hidden('id_user', auth()->user()->id)); ?>


<div class="form-group">

    <?php echo e(Form::label('nombre', 'Nombre del menu')); ?>

    <?php echo e(Form::text('nombre', null, ['class' => 'form-control', 'id' => 'nombre'])); ?>

</div>

<div class="form-group">
    <?php echo e(Form::label('nivel', 'Nivel del menú')); ?>


    <?php if(!Request::is('*/adminmenus/*/edit')): ?>
        <?php echo Form::select('nivel',['Padre' => 'Padre', 'Hijo'=>'Hijo'],'',['class'=>'form-control', 'id'=>'nivel']); ?>

    <?php else: ?>
    <?php echo Form::select('nivel',['Padre' => 'Padre', 'Hijo'=>'Hijo'],$menu->id_nivel,['class'=>'form-control', 'id'=>'nivel']); ?>

    <?php endif; ?>
</div>

<?php if(!Request::is('*/adminmenus/*/edit')): ?>
<div class="form-group" id="sub-nivel"   style="display:none;">
    <?php echo e(Form::label('id_padre', 'Menú padre')); ?>

    <?php echo Form::select('id_padre', $menus_padre, '',['class'=>'form-control','placeholder'=>'Seleccione el menu padre']); ?>

</div>
<?php else: ?>
<div class="form-group" id="sub-nivel">
    <?php echo e(Form::label('id_padre', 'Menú padre')); ?>

    <?php echo Form::select('id_padre', $menus_padre, $menu->id_padre,['class'=>'form-control','placeholder'=>'Seleccione el menu padre']); ?>

</div>
<?php endif; ?>

<div class="form-group">
    <?php echo e(Form::label('id_pagina', 'Página interna')); ?>


    <?php if(Request::is('*/adminmenus/*/edit')): ?>

        <?php if($menu->id_pagina): ?>
            <?php echo e(Form::select('id_pagina', $paginas, $menu->id_pagina, ['class' => 'form-control', 'placeholder'=>'Seleccione la página' ])); ?>

        <?php else: ?>
        <?php echo e(Form::select('id_pagina', $paginas, '', ['class' => 'form-control', 'placeholder'=>'Seleccione la página' ])); ?>

        <?php endif; ?>

    <?php else: ?>
    <?php echo e(Form::select('id_pagina', $paginas, '', ['class' => 'form-control', 'placeholder'=>'Seleccione la página' ])); ?>

    <?php endif; ?>
</div>

<div class="form-group">
    <?php echo e(Form::label('link_externo', 'URL externa')); ?>

    <?php echo e(Form::text('link_externo', null, ['class' => 'form-control', 'id' => 'link_externo'])); ?>

</div>

<div class="form-group">
    <?php echo e(Form::label('estado', 'Estado del menú')); ?>

    <br>
    <label>
    <?php echo e(Form::radio('estado', 'PUBLICADO')); ?> Activo
    </label>
    <label>
    <?php echo e(Form::radio('estado', 'BORRADOR')); ?> Borrador
    </label>
</div>
    <?php echo e(Form::hidden('orden', 0)); ?>

<div class="form-group text-right">
    <?php echo e(Form::submit('Guardar', ['class' => 'btn btn-sm btn-primary'])); ?>

    <a class="btn btn-warning btn-sm"  href="<?php echo e(url('adm/adminmenus')); ?>">Cancelar</a>
</div>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>

    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

    <script  src="<?php echo e(asset('vendor/stringToSlug/src/jquery.stringtoslug.js')); ?>"></script>
    <script  src="<?php echo e(asset('vendor/stringToSlug/src/speakingurl.min.js')); ?>"></script>

    <script src="<?php echo e(asset('vendor/ckeditor/ckeditor.js')); ?>" defer></script>


    <script>


        jQuery(function($){

            //click, para ver opciones de un archivo, en editar pagina
            $(".ver").click(function () {
                $( this ).next( ".filei" ).css( "display", "block" );
            });

            $('input').attr('autocomplete','off');

            //select hijo and show padres
            $("#nivel").change(function(){
                if($(this).val() == "Hijo"){
                $("#sub-nivel").show();
                }else{
                $("#sub-nivel").hide();
                $("#id_padre").val('');
                }

            });
    });




        </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/admin/menus/partials/form.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <div class="contaniner">
        <div class="row">
            <div class="col-md-10">
                <div class="card card-default">
                    <div class="card-header">
                            Editar Noticia
                    </div>

                <div class="card-body">
                    <?php echo Form::model($noticia, ['route' => ['adminnoticias.update', $noticia->id], 'method' => 'PUT', 'files' => true]); ?>

                        <?php echo e(Form::hidden('id', $noticia->id)); ?>


                        <?php echo $__env->make('admin.noticias.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php echo Form::close(); ?>

                </div>
            </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>;

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/admin/noticias/edit.blade.php ENDPATH**/ ?>
<div role="main" class="page">
<?php $__env->startSection('content'); ?>
    <?php if($pagina->img): ?>
        <div class="img-portada" style="background:url('<?php echo e($pagina->img); ?>');"></div>
    <?php endif; ?>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
            <h1><?php echo e($pagina->titulo); ?></h1>
            <hr>
                <?php echo $pagina->body; ?>

                <hr>
        </div>

      </div>
    </div>
</div>

    

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/web/pages/page.blade.php ENDPATH**/ ?>
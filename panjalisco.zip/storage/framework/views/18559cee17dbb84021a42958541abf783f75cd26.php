<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
                <div class="card card-default">
                    <div class="card-header">
                        Articulo
                    </div>

                    <div class="card-body">

                    <?php echo Form::model($articulo, ['route' => ['articuloUpdate', $articulo->id], 'method' => 'PUT', 'files' => true]); ?>



                    <div class="form-group">
                    <?php echo e(Form::label('Numero', 'Número')); ?>

                    <?php echo e(Form::text('Numero', $articulo->Numero, ['class' => 'form-control'])); ?>

                    </div>
                    <div class="form-group">
                    <?php echo e(Form::label('titulo', 'Titulo')); ?>

                    <?php echo e(Form::text('Titulo', $articulo->Titulo, ['class' => 'form-control'])); ?>

                    </div>
                    <div class="form-group">
                    <?php echo e(Form::label('Texto', 'Texto')); ?>

                    <?php echo e(Form::text('Texto', $articulo->Texto, ['class' => 'form-control'])); ?>

                    </div>
                    <div class="form-group">
                    <?php echo e(Form::label('Visible', 'Visibilidad')); ?>

                    <?php echo Form::select('Visible',['1' => 'Visible','0'=>'No visible'],$articulo->Visible,['class'=>'form-control','placeholder'=>'Seleccione una opcion']); ?>

                    </div>
                    <div class="form-group">
                    <?php echo e(Form::label('Orden', 'Orden')); ?>

                    <?php echo e(Form::text('Orden', $articulo->Orden, ['class' => 'form-control'])); ?>

                    </div>
                    <div class="form-group text-right">
                        <?php echo e(Form::submit('Guardar', ['class' => 'btn btn-sm btn-primary'])); ?>

                        <a class="btn btn-warning btn-sm"  href="<?php echo e(url('adm/admintransparencia/articulos')); ?>">Cancelar</a>
                    </div>
                    <?php echo Form::close(); ?>

                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/admin/transparencia/articulo/form.blade.php ENDPATH**/ ?>
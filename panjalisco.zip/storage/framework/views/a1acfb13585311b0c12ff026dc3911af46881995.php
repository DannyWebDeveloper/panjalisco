<!-- create.blade.php -->



<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
                <div class="card card-default">
                    <div class="card-header">
                        Comisión
                        <a href="<?php echo e(route('admincomision.create')); ?>" class="btn btn-sm btn-primary btn-right">Nuevo Integrante</a>
                    </div>

                <div class="card-body">
                    <table class="table table-striped table-hover">
                        <thead>
                        <tr>
                        <th>Nombre</th>
                        <th>Puesto</th>
                        <th>Comité</th>
                        <th>Visible</th>
                        <th colspan="3">&nbsp;</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $comisiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                               <td> <?php echo e($val->nombre); ?></td>
                               <td><?php echo e($val->puesto); ?></td>
                               <td>
                               <?php $__currentLoopData = $comites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($comite->id == $val->id_comite): ?>
                                <?php echo e($comite->nombre); ?>

                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </td>
                               <td>
                               <?php if($val->visible == 1): ?>
                                SI
                                <?php else: ?>
                                NO
                                <?php endif; ?>
                               </td>
                                <td width ="10px">
                                <a href="<?php echo e(route('admincomision.edit', $val->id)); ?>" class="btn">
                                    Editar
                                </a>
                                </td>
                                <td width ="10px">
                                    <?php echo Form::open(['route' => ['admincomision.destroy', $val->id], 'method' => 'DELETE']); ?>

                                        <button class="btn btn-sm btn-danger">Eliminar</button>
                                    <?php echo Form::close(); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>;

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/admin/comision/index.blade.php ENDPATH**/ ?>
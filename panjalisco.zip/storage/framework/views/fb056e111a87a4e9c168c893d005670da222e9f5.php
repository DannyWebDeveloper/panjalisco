<?php echo e(Form::hidden('id_user', auth()->user()->id)); ?>


<div class="form-group">

    <?php echo e(Form::label('titulo', 'Titulo del boletin')); ?>

    <?php echo e(Form::text('titulo', null, ['class' => 'form-control', 'id' => 'nombre'])); ?>

</div>

<div class="form-group">
    <?php echo e(Form::label('documento', 'Documento')); ?>

    <?php echo e(Form::file('documento', ['class' => 'form-control' ])); ?>

    <br>
    <?php if(isset($boletin)): ?>
    <b>Actual documento: </b>
    <a><?php echo e($boletin->documento); ?></a>
    <?php endif; ?>
</div>

<div class="form-group">
        <?php echo e(Form::label('visible', 'Visibilidad')); ?>

        <?php echo Form::select('visible',['1' => 'Visible','0'=>'No visible'],null,['class'=>'form-control','placeholder'=>'Seleccione una opcion']); ?>

</div>
<div class="form-group">
       <?php echo e(Form::label('fecha', 'Fecha de boleitn')); ?>

       <?php echo e(Form::text('fecha', null,  ['class' => 'form-control datepicker' ])); ?>

</div>
<div class="form-group">
    <?php echo e(Form::submit('Guardar', ['class' => 'btn btn-sm btn-primary'])); ?>

    <a class="btn btn-warning btn-sm"  href="<?php echo e(URL::previous()); ?>">Cancelar</a>
</div>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>

    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

    <script  src="<?php echo e(asset('vendor/stringToSlug/src/jquery.stringtoslug.js')); ?>"></script>
    <script  src="<?php echo e(asset('vendor/stringToSlug/src/speakingurl.min.js')); ?>"></script>

    <script src="<?php echo e(asset('vendor/ckeditor/ckeditor.js')); ?>" defer></script>


    <script>
        jQuery(function($){
            // $( ".datepicker" ).focus(function(){
                $( ".datepicker" ).datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'yy-mm-dd'
                });
            //});
            $('input').attr('autocomplete','off');
        });
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/admin/boletines/partials/form.blade.php ENDPATH**/ ?>
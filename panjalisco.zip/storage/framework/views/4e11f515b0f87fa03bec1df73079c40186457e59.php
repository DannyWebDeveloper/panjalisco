<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo asset('css/slider.css'); ?>">

    <div class="container justity-center">
        <div class="row">
            <div class="col-md-10 col-offset-2">
                <div class="card card-default">
                    <div class="card-header">
                            Editar imagen de mapa
                    </div>

                <div class="card-body">

                    <?php echo Form::model($mapa, ['route' => ['adminmapas.update', $mapa->id], 'method' => 'PUT', 'files' => true]); ?>

                        <?php echo e(Form::hidden('id', $mapa->id)); ?>

                        <?php echo $__env->make('admin.mapas.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo Form::close(); ?>


                </div>
            </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>;



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/admin/mapas/edit.blade.php ENDPATH**/ ?>
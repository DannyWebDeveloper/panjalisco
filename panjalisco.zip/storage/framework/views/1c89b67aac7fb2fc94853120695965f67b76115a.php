
<div class="form-group">

    <?php echo e(Form::label('nombre', 'Nombre de la categoria')); ?>

    <?php echo e(Form::text('nombre', null, ['class' => 'form-control', 'id' => 'nombre'])); ?>

</div>

<div class="form-group">

    <?php echo e(Form::label('slug', 'URL Amigable')); ?>

    <?php echo e(Form::text('slug', null, ['class' => 'form-control', 'id' => 'slug'])); ?>

</div>
<div class="form-group">
    <?php echo e(Form::submit('Guardar', ['class' => 'btn btn-sm btn-primary'])); ?>

    <a class="btn btn-warning btn-sm"  href="<?php echo e(url('adm/admincategorias')); ?>">Cancelar</a>
</div>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script  src="<?php echo e(asset('vendor/stringToSlug/src/jquery.stringtoslug.js')); ?>"></script>
    <script  src="<?php echo e(asset('vendor/stringToSlug/src/speakingurl.min.js')); ?>"></script>
    <script>
        jQuery(function($){

            $("#nombre, #slug").stringToSlug({
                callback: function(text){
                    $("#slug").val(text);
                }
            })


        });

        </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/admin/categorias/partials/form.blade.php ENDPATH**/ ?>
<table class="table table-bordered table-striped table-condense">
    <thead>
        <tr>
        <th>No.</th>
        <th colspan="2">Título</th>
        </tr>
    </thead>
        <tbody>
<?php $__currentLoopData = $parrafos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parrafo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr class="item-parrafo" data-url="<?php echo e(route('transparencia.inciso', ['id_parrafo' => $parrafo->id])); ?>" onclick="$('#parr').append('<a>-> Parrafo <?php echo e($parrafo->Numero_Parrafo); ?></a>')">
        <td> <?php echo e($parrafo->Numero_Parrafo); ?> </td>
        <td> <?php echo e($parrafo->Titulo); ?> </td>
        <td>
           <?php $__currentLoopData = $doc_parrafos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($doc->id_parrafo == $parrafo->id && $doc->Archivo != 'NULL'): ?>
                <p>
                    <?php echo e($doc->NombreDocumento); ?> - <?php echo e($doc->FechaDocumento); ?>

                </p>
                <?php endif; ?>
                <?php if($doc->id_parrafo == $parrafo->id && $doc->Archivo == 'NULL'): ?>
                  <p><a href="<?php echo e($doc->Link); ?>">Link </a> - <?php echo e($doc->FechaDocumento); ?></p>
                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
    </tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>



<script>



$('.item-parrafo').on('click', function(){
            var token = $('meta[name="csrf-token"]').attr('content'),
            $this = $(this),
            url = $this.data('url');
            $.post(url,
        {
            _token: token,
            id: 1,
        },
        function(data, status){
            $("#list-incisos").empty().html(data);
            $("#list-parrafos").hide()
        });
    });
</script>
<?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/web/transparencia/parrafos.blade.php ENDPATH**/ ?>
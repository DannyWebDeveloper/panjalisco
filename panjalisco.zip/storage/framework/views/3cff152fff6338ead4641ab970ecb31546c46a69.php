<main role="main">

  <div id="myCarousel" class="carousel slide container" data-ride="carousel">
    <ol class="carousel-indicators">
    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($loop->first): ?>
        <li data-target="#myCarousel" data-slide-to="<?php echo e($loop->iteration-1); ?>" class="active"></li>
        <?php else: ?>
        <li data-target="#myCarousel" data-slide-to="<?php echo e($loop->iteration-1); ?>"></li>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </ol>
    <div class="carousel-inner">
        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($loop->first): ?>
        <div class="carousel-item active">
        <?php else: ?>
        <div class="carousel-item">
        <?php endif; ?>
            <img class="bd-placeholder-img" width="100%" height="100%" focusable="false" role="img" src="<?php echo e($sli->img); ?>">
            <div class="carousel-caption text-left">
                <p><?php echo e($sli->descripcion); ?></p>
                <?php if($sli->link): ?>
                <a class="btn"><?php echo e($sli->link); ?></a>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>


  <div class="container">

    <!-- Three columns of text below the carousel -->
    <h2>ÚLTIMAS NOTICIAS</h2>
    <div class="row">
            <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="card border-primary flex-md-row mb-4 shadow-sm h-md-250">
                <img class="card-img-left flex-auto d-none d-lg-block" alt="<?php echo e($nota->titulo); ?>" src="<?php echo e($nota->img); ?>" style="width: 150px; height: 150px;">
                    <div class="card-body d-flex flex-column align-items-start">

                        <strong class="d-inline-block mb-2 text-primary"><?php echo e($nota->nombre); ?></strong>
                        <h6 class="mb-0">
                            <a class="text-dark" href="#"><?php echo e($nota->titulo); ?></a>
                        </h6>
                        <div class="mb-1 text-muted small"><?php echo e($nota->created_at->format("m/d/Y")); ?></div>
                        <p class="card-text mb-auto resumen-nota"><?php echo e($nota->extracto); ?></p>
                        <a class="btn btn-outline-primary btn-sm" role="button" href="<?php echo e(route('noticia', $nota->slug_noticia)); ?>">Leer nota</a>
                        </div>

                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-12">
                <a href="<?php echo e(route('noticias')); ?>" class="show-more">Ver todas</a>
            </div>

    </div><!-- /.row -->
    <br><br>
    <div class="row map-links">
        <?php $__currentLoopData = $mapas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $map): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-6">
            <a href="<?php echo e($map->link); ?>"><img src="<?php echo e(asset($map->img)); ?>" class="img_mapa"></a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>


  </div><!-- /.container -->


  

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panjalisco\resources\views/web/inicio.blade.php ENDPATH**/ ?>
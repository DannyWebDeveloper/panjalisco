<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Imagen_mapa extends Model
{
    //
    protected $fillable = ['tipo', 'img', 'link', 'visible'];
}
